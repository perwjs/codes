=======
Credits
=======

Development Lead
----------------

* Mishbah Razzaque (mishbahr) <mishbahx@gmail.com>

Contributors
------------

* John Matthew (jfmatth) <john@compunique.com>
* moemen <moemenology@gmail.com>
* Alwerdani <alwerdani@gmail.com>
* Weizhong Tu (twz915) <tuweizhong@163.com>
* Ahmed Maher (mxahmed) <ahmedmaherelmitwally@gmail.com>